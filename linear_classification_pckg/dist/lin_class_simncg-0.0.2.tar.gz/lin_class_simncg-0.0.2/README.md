# Library for Linear Classification
This library contains functions for solving linear classification project. 